// social.js
(() => {
  // ===== Helpers =====
  const $  = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));
  const getText = (sel, fallback = "") => {
    const el = $(sel);
    return el ? (el.textContent || "").trim() : fallback;
  };

  // ===== 1) QR dinámico + descarga =====
  function initQR() {
    const box = $("#qrcodeContainer");
    const btn = $("#download-qr");
    const nombre = getText(".card-title", "MiTarjeta");
    if (!box || typeof QRCode === "undefined") return;

    const render = () => {
      box.innerHTML = "";
      new QRCode(box, {
        text: window.location.href,
        width: 180,
        height: 180,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H,
      });
    };
    render();

    if (btn) {
      btn.addEventListener("click", () => {
        const canvas = box.querySelector("canvas");
        if (!canvas) return;
        const a = document.createElement("a");
        a.download = `QR-${nombre}.png`;
        a.href = canvas.toDataURL();
        a.click();
      });
    }
  }

  // ===== 2) Compartir (Web Share API) =====
  function initShare() {
    const btn = $("#compartirBtnphp");
    if (!btn) return;

    btn.addEventListener("click", () => {
      const meta  = $('meta[name="nombre"]');
      const title = (meta && meta.getAttribute("content")) || "Compartir tarjeta";
      if (navigator.share) {
        navigator.share({ title, text: "", url: window.location.href }).catch(console.error);
      } else {
        alert("La funcionalidad de compartir no es compatible en este dispositivo/navegador.");
      }
    });
  }

  // ===== 3) Modal QR =====
  function initModalQR() {
    const openBtn = $("#openModalButton");
    const closeBtn = $("#closeModalButton");
    const modal   = $("#modalQR");
    if (!modal) return;

    if (openBtn) openBtn.addEventListener("click", () => (modal.style.display = "block"));
    if (closeBtn) closeBtn.addEventListener("click", () => (modal.style.display = "none"));
    window.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });
  }

  // ===== 4) Modal Formulario + WhatsApp =====
  function initModalFormulario() {
    const icono   = $("#icono-redireccion");
    const modal   = $("#modalFormulario");
    const closeBtn= $("#closeFormButton");
    const form    = $("#contactForm");
    if (!modal) return;

    if (icono)   icono.addEventListener("click", () => (modal.style.display = "block"));
    if (closeBtn) closeBtn.addEventListener("click", () => (modal.style.display = "none"));
    window.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });

    if (form) {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        // En social usas: #name, #phone, #email, #company
        const name    = $("#name")?.value || "";
        const phone   = $("#phone")?.value || "";
        const email   = $("#email")?.value || "";
        const company = $("#company")?.value || "";

        const msg = encodeURIComponent(
          `Hola, deseo intercambiar información de contacto. Adjunto mis datos:\n\n` +
          `Nombre: ${name}\nTeléfono: ${phone}\nEmail: ${email}\nEmpresa: ${company}`
        );
        window.open(`https://wa.me/527713258935?text=${msg}`);
        modal.style.display = "none";
      });
    }
  }

  // ===== 5) Botón "Subir" (scroll-to-top) =====
  function initScrollTop() {
    const btn = $("#myBtn");
    const container = $(".container"); // si no existe, usa documento
    if (!btn) return;

    const getTop = () =>
      container ? container.scrollTop : (window.scrollY || document.documentElement.scrollTop);

    const onScroll = () => { btn.style.display = getTop() > 20 ? "block" : "none"; };

    if (container) container.addEventListener("scroll", onScroll, { passive: true });
    else window.addEventListener("scroll", onScroll, { passive: true });

    btn.addEventListener("click", () => {
      if (container) container.scrollTo({ top: 0, behavior: "smooth" });
      else window.scrollTo({ top: 0, behavior: "smooth" });
    });

    onScroll();
  }

  // ===== 6) Notificaciones (IntersectionObserver) =====
  function initNotifications() {
    const notifications = $$(".notification");
    if (!notifications.length) return;

    let lastScrollTop = window.scrollY;
    const set = (el, show) => {
      el.classList.toggle("show", show);
      el.classList.toggle("hide", !show);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const scrollTop = window.scrollY;
          const scrollingUp = scrollTop < lastScrollTop;

          if (entry.isIntersecting) {
            set(entry.target, true);
          } else if (scrollingUp) {
            const idx = notifications.indexOf(entry.target);
            for (let i = notifications.length - 1; i >= idx; i--) set(notifications[i], false);
          } else {
            set(entry.target, false);
          }

          lastScrollTop = scrollTop;
        });
      },
      { threshold: 0.1 }
    );

    notifications.forEach((n) => observer.observe(n));
  }

  // ===== 7) Acceso directo (.url Windows) =====
  function initAccesoDirecto() {
    const btn = $("#acceso-directo");
    if (!btn) return;

    btn.addEventListener("click", () => {
      const nombre = getText(".card-title", "Acceso directo");
      const urlActual = window.location.href;
      const icon = $(".profile-picture img")?.getAttribute("src") || "";
      const contenido = `[InternetShortcut]\nURL=${urlActual}\nIconFile=${icon}\nIconIndex=0`;

      const blob = new Blob([contenido], { type: "text/plain" });
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement("a");
      a.href = url;
      a.download = `${nombre}.url`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  }

  // ===== 8) Swiper (galería + video) =====
  function initSwipers() {
    if (typeof Swiper === "undefined") return;

    if ($(".mySwiper-gallery")) {
      new Swiper(".mySwiper-gallery", {
        autoplay: { delay: 5000, disableOnInteraction: false },
        loop: true,
        grabCursor: true,
        slidesPerView: 1,
        spaceBetween: 10,
        touchEventsTarget: "wrapper",
      });
    }

    if ($(".mySwiper-video")) {
      new Swiper(".mySwiper-video", {
        slidesPerView: 1,
        spaceBetween: 30,
        centeredSlides: true,
        loop: true,
        navigation: { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" },
        pagination: false,
        touchRatio: 1,
        on: {
          slideChange() {
            $$(".mySwiper-video iframe").forEach((iframe) => (iframe.src = iframe.src));
          },
        },
      });
    }
  }

  // ===== Boot =====
  document.addEventListener("DOMContentLoaded", () => {
    initQR();
    initShare();
    initModalQR();
    initModalFormulario();
    initScrollTop();
    initNotifications();
    initAccesoDirecto();
    initSwipers();
  });
})();
