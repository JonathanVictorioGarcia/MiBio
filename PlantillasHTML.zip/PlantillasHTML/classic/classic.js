// classic.js
(() => {
  // ========== Helpers ==========
  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));
  const getText = (sel, fallback = "") => {
    const el = $(sel);
    return el ? (el.textContent || "").trim() : fallback;
  };

  // ========== 1) QR dinámico + descargar ==========
  function initQR() {
    const qrcodeContainer = $("#qrcodeContainer");
    const downloadBtn = $("#download-qr");
    const nombre = getText(".card-title", "MiTarjeta");

    if (!qrcodeContainer || typeof QRCode === "undefined") return;

    const generarQR = () => {
      const currentUrl = window.location.href;
      qrcodeContainer.innerHTML = "";
      new QRCode(qrcodeContainer, {
        text: currentUrl,
        width: 180,
        height: 180,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H,
      });
    };

    generarQR();

    if (downloadBtn) {
      downloadBtn.addEventListener("click", () => {
        const canvas = qrcodeContainer.querySelector("canvas");
        if (!canvas) return;
        const link = document.createElement("a");
        link.download = `QR-${nombre}.png`;
        link.href = canvas.toDataURL();
        link.click();
      });
    }
  }

  // ========== 2) Compartir (Web Share API) ==========
  function initShare() {
    const btn = $("#compartirBtnphp");
    if (!btn) return;

    btn.addEventListener("click", () => {
      const nombreMetaTag = $('meta[name="nombre"]');
      const nombre =
        (nombreMetaTag && nombreMetaTag.getAttribute("content")) ||
        "Compartir tarjeta";

      if (navigator.share) {
        navigator
          .share({
            title: nombre,
            text: "",
            url: window.location.href,
          })
          .catch((err) => console.error("Error al compartir:", err));
      } else {
        alert(
          "La funcionalidad de compartir no es compatible en este dispositivo/navegador."
        );
      }
    });
  }

  // ========== 3) Modal QR ==========
  function initModalQR() {
    const openBtn = $("#openModalButton");
    const closeBtn = $("#closeModalButton");
    const modal = $("#modalQR");
    if (!modal) return;

    if (openBtn) openBtn.addEventListener("click", () => (modal.style.display = "block"));
    if (closeBtn) closeBtn.addEventListener("click", () => (modal.style.display = "none"));
    window.addEventListener("click", (e) => {
      if (e.target === modal) modal.style.display = "none";
    });
  }

  // ========== 4) Modal Formulario + WhatsApp ==========
  function initModalFormulario() {
    const icono = $("#icono-redireccion");
    const modal = $("#modalFormulario");
    const closeBtn = $("#closeFormButton");
    const form = $("#contactForm");
    if (!modal) return;

    if (icono) icono.addEventListener("click", () => (modal.style.display = "block"));
    if (closeBtn) closeBtn.addEventListener("click", () => (modal.style.display = "none"));
    window.addEventListener("click", (e) => {
      if (e.target === modal) modal.style.display = "none";
    });

    if (form) {
      form.addEventListener("submit", (event) => {
        event.preventDefault();

        // OJO: tus IDs aquí eran name, phone, email, company
        const name = $("#name")?.value || "";
        const phone = $("#phone")?.value || "";
        const email = $("#email")?.value || "";
        const company = $("#company")?.value || "";

        const whatsappMessage = encodeURIComponent(
          `Hola, deseo intercambiar información de contacto. Adjunto mis datos:\n\nNombre: ${name}\nTeléfono: ${phone}\nEmail: ${email}\nEmpresa: ${company}`
        );

        // Cambia el número si corresponde
        window.open(`https://wa.me/527713258935?text=${whatsappMessage}`);
        modal.style.display = "none";
      });
    }
  }

  // ========== 5) Botón “Subir” (scroll top) ==========
  function initScrollTop() {
    const btn = $("#myBtn");
    const container = $(".container"); // si no existe, usamos documento
    if (!btn) return;

    const getScrollTop = () =>
      container ? container.scrollTop : (window.scrollY || document.documentElement.scrollTop);

    const onScroll = () => {
      btn.style.display = getScrollTop() > 20 ? "block" : "none";
    };

    if (container) {
      container.addEventListener("scroll", onScroll, { passive: true });
    } else {
      window.addEventListener("scroll", onScroll, { passive: true });
    }

    // click → subir
    btn.addEventListener("click", () => {
      if (container) {
        container.scrollTo({ top: 0, behavior: "smooth" });
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    });

    onScroll();
  }

  // ========== 6) Notificaciones (IntersectionObserver) ==========
  function initNotifications() {
    const notifications = $$(".notification");
    if (!notifications.length) return;

    let lastScrollTop = window.scrollY;

    const handleAnimation = (el, show) => {
      el.classList.toggle("show", show);
      el.classList.toggle("hide", !show);
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const scrollTop = window.scrollY;
          const scrollingUp = scrollTop < lastScrollTop;
          const isVisible = entry.isIntersecting;

          if (isVisible) {
            handleAnimation(entry.target, true);
          } else if (scrollingUp) {
            const index = notifications.indexOf(entry.target);
            for (let i = notifications.length - 1; i >= index; i--) {
              handleAnimation(notifications[i], false);
            }
          } else {
            handleAnimation(entry.target, false);
          }

          lastScrollTop = scrollTop;
        });
      },
      { threshold: 0.1 }
    );

    notifications.forEach((n) => observer.observe(n));
  }

  // ========== 7) Acceso Directo (.url Windows) ==========
  function initAccesoDirecto() {
    const btn = $("#acceso-directo");
    if (!btn) return;

    btn.addEventListener("click", () => {
      const nombre = getText(".card-title", "Acceso directo");
      const urlActual = window.location.href;
      const imagenSrc = $(".profile-picture img")?.getAttribute("src") || "";

      const contenidoURL = `[InternetShortcut]\nURL=${urlActual}\nIconFile=${imagenSrc}\nIconIndex=0`;
      const blob = new Blob([contenidoURL], { type: "text/plain" });
      const url = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = `${nombre}.url`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  }

  // ========== 8) Swiper (galería + video) ==========
  function initSwipers() {
    if (typeof Swiper === "undefined") return;

    // Galería
    if ($(".mySwiper-gallery")) {
      new Swiper(".mySwiper-gallery", {
        autoplay: { delay: 5000, disableOnInteraction: false },
        loop: true,
        grabCursor: true,
        slidesPerView: 1,
        spaceBetween: 10,
        touchEventsTarget: "wrapper",
      });
    }

    // Video
    if ($(".mySwiper-video")) {
      new Swiper(".mySwiper-video", {
        slidesPerView: 1,
        spaceBetween: 30,
        centeredSlides: true,
        loop: true,
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
        pagination: false,
        touchRatio: 1,
        on: {
          slideChange: function () {
            $$(".mySwiper-video iframe").forEach((iframe) => {
              iframe.src = iframe.src; // reinicia para pausar
            });
          },
        },
      });
    }
  }

  // ========== Boot ==========
  document.addEventListener("DOMContentLoaded", () => {
    initQR();
    initShare();
    initModalQR();
    initModalFormulario();
    initScrollTop();
    initNotifications();
    initAccesoDirecto();
    initSwipers();
  });
})();
