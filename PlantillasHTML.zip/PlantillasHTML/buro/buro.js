// buro.js
(() => {
  // Utilidad: obtiene texto seguro
  const getText = (sel, fallback = "") => {
    const el = document.querySelector(sel);
    return el ? (el.textContent || "").trim() : fallback;
  };

  // === 1) QR dinámico + descargar ===
  function initQR() {
    const qrcodeContainer = document.getElementById("qrcodeContainer");
    const nombre = getText(".card-title", "MiTarjeta");
    const downloadBtn = document.getElementById("download-qr");

    if (!qrcodeContainer || typeof QRCode === "undefined") return;

    const generarQR = () => {
      const currentUrl = window.location.href;
      qrcodeContainer.innerHTML = "";
      // QRCode global proviene de ./qr/qrcode.min.js
      new QRCode(qrcodeContainer, {
        text: currentUrl,
        width: 180,
        height: 180,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H,
      });
    };

    generarQR();

    if (downloadBtn) {
      downloadBtn.addEventListener("click", () => {
        const canvas = qrcodeContainer.querySelector("canvas");
        if (!canvas) return;
        const fileName = `QR-${nombre}.png`;
        const link = document.createElement("a");
        link.download = fileName;
        link.href = canvas.toDataURL();
        link.click();
      });
    }
  }

  // === 2) Compartir (Web Share API) ===
  function initShare() {
    const btn = document.getElementById("compartirBtnphp");
    if (!btn) return;

    btn.addEventListener("click", () => {
      const nombreMetaTag = document.querySelector('meta[name="nombre"]');
      const nombre =
        (nombreMetaTag && nombreMetaTag.getAttribute("content")) ||
        "Compartir tarjeta";

      if (navigator.share) {
        navigator
          .share({
            title: nombre,
            text: "",
            url: window.location.href,
          })
          .catch((err) => console.error("Error al compartir:", err));
      } else {
        alert(
          "La funcionalidad de compartir no es compatible en este dispositivo/navegador."
        );
      }
    });
  }

  // === 3) Modal QR simple ===
  function initModalQR() {
    const openBtn = document.getElementById("openModalButton");
    const closeBtn = document.getElementById("closeModalButton");
    const modal = document.getElementById("modalQR");
    if (!modal) return;

    if (openBtn) {
      openBtn.addEventListener("click", () => (modal.style.display = "block"));
    }
    if (closeBtn) {
      closeBtn.addEventListener("click", () => (modal.style.display = "none"));
    }
    window.addEventListener("click", (e) => {
      if (e.target === modal) modal.style.display = "none";
    });
  }

  // === 4) Modal Formulario + envío a WhatsApp ===
  function initModalFormulario() {
    const icono = document.getElementById("icono-redireccion");
    const modal = document.getElementById("modalFormulario");
    const closeBtn = document.getElementById("closeFormButton");
    const form = document.getElementById("contactForm");

    if (icono && modal) {
      icono.addEventListener("click", () => (modal.style.display = "block"));
    }
    if (closeBtn && modal) {
      closeBtn.addEventListener("click", () => (modal.style.display = "none"));
    }
    window.addEventListener("click", (e) => {
      if (e.target === modal) modal.style.display = "none";
    });

    if (form && modal) {
      form.addEventListener("submit", (event) => {
        event.preventDefault();
        const name = document.getElementById("nameForm")?.value || "";
        const phone = document.getElementById("phoneForm")?.value || "";
        const email = document.getElementById("emailForm")?.value || "";
        const company = document.getElementById("companyForm")?.value || "";

        const whatsappMessage = encodeURIComponent(
          `Hola, deseo intercambiar información de contacto. Adjunto mis datos:\n\nNombre: ${name}\nTeléfono: ${phone}\nEmail: ${email}\nEmpresa: ${company}`
        );

        // Cambia el número si lo necesitas
        window.open(`https://wa.me/527713258935?text=${whatsappMessage}`);
        modal.style.display = "none";
      });
    }
  }

  // === 5) Botón subir (scroll to top) ===
  function initScrollTop() {
    const btn = document.getElementById("myBtn");
    // Contenedor scrollable (si usas un contenedor de layout); fallback: documento
    const container =
      document.querySelector(".container") || document.documentElement;

    if (!btn) return;

    const scrollFunction = () => {
      const top =
        container === document.documentElement
          ? window.scrollY || document.documentElement.scrollTop
          : container.scrollTop;
      btn.style.display = top > 20 ? "block" : "none";
    };

    // Mostrar/ocultar según se haga scroll
    if (container === document.documentElement) {
      window.addEventListener("scroll", scrollFunction, { passive: true });
    } else {
      container.addEventListener("scroll", scrollFunction, { passive: true });
    }

    // Click → scroll suave al tope
    btn.addEventListener("click", () => {
      if (container === document.documentElement) {
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else {
        container.scrollTo({ top: 0, behavior: "smooth" });
      }
    });

    // Estado inicial
    scrollFunction();
  }

  // === 6) Notificaciones (IntersectionObserver) ===
  function initNotifications() {
    const notifications = Array.from(
      document.querySelectorAll(".notification")
    );
    if (!notifications.length) return;

    let lastScrollTop = window.scrollY;

    const handleAnimation = (el, show) => {
      if (show) {
        el.classList.add("show");
        el.classList.remove("hide");
      } else {
        el.classList.add("hide");
        el.classList.remove("show");
      }
    };

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const scrollTop = window.scrollY;
          const scrollingUp = scrollTop < lastScrollTop;
          const isVisible = entry.isIntersecting;

          if (isVisible) {
            handleAnimation(entry.target, true);
          } else if (scrollingUp) {
            const index = notifications.indexOf(entry.target);
            for (let i = notifications.length - 1; i >= index; i--) {
              handleAnimation(notifications[i], false);
            }
          } else {
            handleAnimation(entry.target, false);
          }

          lastScrollTop = scrollTop;
        });
      },
      { threshold: 0.1 }
    );

    notifications.forEach((n) => observer.observe(n));
  }

  // === 7) Acceso directo .url (Windows) ===
  function initAccesoDirecto() {
    const btn = document.getElementById("acceso-directo");
    if (!btn) return;

    btn.addEventListener("click", () => {
      const nombre = getText(".card-title", "Acceso directo");
      const urlActual = window.location.href;
      const img = document.querySelector(".profile-picture img");
      const imagenSrc = img ? img.getAttribute("src") : "";

      const contenidoURL = `[InternetShortcut]\nURL=${urlActual}\nIconFile=${imagenSrc}\nIconIndex=0`;
      const blob = new Blob([contenidoURL], { type: "text/plain" });
      const url = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = `${nombre}.url`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  }

  // === 8) Swiper (galería + video) ===
  function initSwipers() {
    // Requiere Swiper global (CDN). Si no está, salimos.
    if (typeof Swiper === "undefined") return;

    // Galería
    const galleryEl = document.querySelector(".mySwiper-gallery");
    if (galleryEl) {
      new Swiper(".mySwiper-gallery", {
        autoplay: {
          delay: 5000,
          disableOnInteraction: false,
        },
        loop: true,
        grabCursor: true,
        slidesPerView: 1,
        spaceBetween: 10,
        touchEventsTarget: "wrapper",
      });
    }

    // Video
    const videoEl = document.querySelector(".mySwiper-video");
    if (videoEl) {
      new Swiper(".mySwiper-video", {
        slidesPerView: 1,
        spaceBetween: 30,
        centeredSlides: true,
        loop: true,
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
        pagination: false,
        touchRatio: 1,
        on: {
          slideChange: function () {
            // Reinicia todos los iframes para pausar videos embebidos
            document
              .querySelectorAll(".mySwiper-video iframe")
              .forEach((iframe) => {
                iframe.src = iframe.src;
              });
          },
        },
      });
    }
  }

  // === Boot ===
  document.addEventListener("DOMContentLoaded", () => {
    initQR();
    initShare();
    initModalQR();
    initModalFormulario();
    initScrollTop();
    initNotifications();
    initAccesoDirecto();
    initSwipers();
  });
})();
